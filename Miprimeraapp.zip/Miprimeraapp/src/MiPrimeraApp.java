/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GreciaGSZ
 */
public class MiPrimeraApp {
    private String nombre,sexo; //voy a mover membresia de lugar porque quiero que sea con numeros
    private double edad,inversion,premio,oferta,ganancia, membresia;
    
    
    
    //aqui va mi constructor
    
    public MiPrimeraApp(String nombre, String sexo, double membresia, double edad, double inversion, double oferta, double ganancia, double premio){
        
        this.nombre=nombre;
        this.sexo=sexo;
        this.membresia=membresia;
        this.edad=edad;
        this.inversion=inversion;
        this.oferta=oferta;
        this.premio=premio;
        this.ganancia=ganancia;
        
        
        
    }
    
    
    
    
    
    //aqui acaba el constructor, no puse ni premio ni oferta ¿los borro? 
    public double nuevopremio (double oferta){
        if(oferta==2){
            premio=premio*1.20;
            
        }
        if(oferta==3){
            premio=premio*1.40;
          
        }
      
      return premio;      
                  
    }
    
    
    
    
    //voy a hacer un metodo que me calcule la ganancia
    // aqui puse premi
    public double gananciados (double premio){
        if(premio>inversion){
           return ganancia=premio-inversion;
        }
        else{
            ganancia=0;
            return ganancia;
        }
    }
    
    
     public String getName(){
        return nombre; 
    }
     
    public double getGanancia(){
        return ganancia;
    }
    
    public double getPremio(){
        return premio; 
    }
    
   public double getOferta(){
       return oferta;
   }
    public double getMembresia(){
        return membresia;
    }
}
