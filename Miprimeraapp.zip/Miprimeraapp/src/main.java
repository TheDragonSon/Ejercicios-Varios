
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GreciaGSZ
 */
public class main {

    public static String nombre,sexo; 
    public static double edad,inversion,premio,oferta,ganancia,membresia;
    public static Scanner leer = new Scanner(System.in);
    
    
    
    
    
    public static void main(String[] args) {
        
        System.out.println("¡Hola! ¿Cuál es tu nombre?");
        nombre=leer.nextLine();
        
        System.out.println("Sexo: ?");
        sexo=leer.nextLine();
        
        System.out.println("Membresia 1)bronce 2)plata 3)oro 4)platino");
        membresia=leer.nextDouble();
        
        System.out.println("Edad: ");
        edad=leer.nextDouble();
        
        System.out.println("¿con cuanto dinero iniciaste el dia de hoy?");
        inversion=leer.nextDouble();
        
        System.out.println("¿de cuánto fue tu premio?");
        premio=leer.nextDouble();
     
        System.out.println("¿Tienes alguna oferta disponible? 1)no 2)20% 3)40%");
        oferta=leer.nextDouble();
        
        
        // public MiPrimeraApp(String nombre, String sexo, String membresia, double edad, double inversion)
        
        MiPrimeraApp persona1=new MiPrimeraApp(nombre,sexo,membresia,edad,inversion,oferta,ganancia, premio);
        
        System.out.println(persona1.getName()+" ¡gracias por jugar con nosotros!");
        
    /*    if(oferta!=0){
            if(oferta==1){
                premio=premio*1.2;
            }
            else {
                premio=premio*1.4;
            }
                
        } */
        double p=persona1.nuevopremio(oferta);
        double x=persona1.gananciados(p);
        
        double g= persona1.getMembresia();
        // double x = persona1.getGanancia();
        if(x>1000 && g<=3){
            g ++;
            System.out.println("Felicidades, tu membresia ha subido al siguiente nivel, ¡jugando ganas siempre!");
            
        }
        
        else if(x>1000 && g==4){
            System.out.println(persona1.getName()+"¡Eres lo máximo! Espera sorpesas especiales, sólo para ti ");
        }
        else if(x<1000){
            System.out.println("Ganar es divertido, sigue jugando");
        }
      
        
        
        
        
        
        
    }
    
}
